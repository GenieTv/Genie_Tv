# plugin.video.livestreamer
A wrapper around the python library livestreamer for playing videos supported by the livestreamer module.

- Author: blxd et al.
- Version: 1.12.2-blxd3
- Github: https://github.com/blxd/plugin.video.livestreamer, https://github.com/chrippa/livestreamer

## Download and Installation

- This is a support plugin and provides no user interface other than configuration.
- Simply download [plugin.video.livestreamer-1.12.2-blxd3.zip](https://github.com/blxd/plugin.video.livestreamer/releases/download/v1.12.2-blxd3/plugin.video.livestreamer-1.12.2-blxd3.zip) file and install it in Kodi, you will also need the script.module.xbmcswift2 addon.
- Or install my [repo add-on](https://github.com/blxd/repository.blxd.plugins) and then install the livestreamer add-on from there.
